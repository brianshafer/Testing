#! /bin/bash
#
# merge to master.sh
#

echo "called here"
git show-ref
git push origin HEAD:master